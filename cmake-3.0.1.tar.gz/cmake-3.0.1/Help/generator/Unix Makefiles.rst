Unix Makefiles
--------------

Generates standard UNIX makefiles.

A hierarchy of UNIX makefiles is generated into the build tree.  Any
standard UNIX-style make program can build the project through the
default make target.  A "make install" target is also provided.
